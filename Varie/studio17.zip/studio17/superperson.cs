using System;

namespace studio17
 {
//     class SuperPerson : Person
//     // {
//     //     public SuperPerson(string firstName, string lastname) :
//     //         base(firstName, lastname)
//     //     { }

//         public void fly()
//         {
//             Console.WriteLine("I'm Neo and I'm flying!\n WAKE UUUUUUP!!!!");
//         }
//     }

}
